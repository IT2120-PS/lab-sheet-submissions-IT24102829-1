setwd("C:\Users\V I C T U S\OneDrive\Documents\Desktop\IT24102829")
#Exercise
#1
1-pbinom(46,size = 50,prob = 0.85)

sum(dbinom(47:50,size = 50 , prob = 0.85))

#2
dpois(15,lambda = 12)
1-ppois(15,lambda =12)

#practising quetion(2)
#part 1
#part2
#part3
dpois(6,5)
#part4
ppois(6,5,lower.tail = FALSE)
